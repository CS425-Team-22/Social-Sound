package com.example.soundsocia;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageButton;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.spotify.android.appremote.api.ConnectionParams;
import com.spotify.android.appremote.api.Connector;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.protocol.client.ErrorCallback;

import java.util.Arrays;
import java.util.List;

// Second screen of the program that displays the music
// player for the user
public class SecondActivity extends AppCompatActivity {
    private static final String TAG = SecondActivity.class.getSimpleName();

    private static final String CLIENT_ID = "6434a1e4e1f44f328888e90d23a94e92";
    private static final String REDIRECT_URI = "https://com.example.soundsocia/callback/";
    private static final String TRACK_URI = "spotify:track:4IWZsfEkaK49itBwCTFDXQ";

    private static SpotifyAppRemote mSecondSpotifyAppRemote;

    // Buttons and views for the user to see the player
    TextView mPlayerTrack;
    ImageView mCoverView;
    AppCompatImageButton mPlayPauseButton;
    AppCompatImageButton mSkipNextButton;
    AppCompatImageButton mSkipPrevButton;
    AppCompatImageButton mSeekForwardButton;
    AppCompatImageButton mSeekBackButton;
    Button mReturnButton;

    List<View> mViews;

    private final ErrorCallback mErrorCallback = this::logError;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        mCoverView = findViewById(R.id.image);
        mPlayerTrack = findViewById(R.id.current_track_label);
        mPlayPauseButton = findViewById(R.id.play_pause_button);
        mSkipNextButton = findViewById(R.id.skip_next_button);
        mSkipPrevButton = findViewById(R.id.skip_prev_button);
        mSeekForwardButton = findViewById(R.id.seek_forward_button);
        mSeekBackButton = findViewById(R.id.seek_back_button);
        mReturnButton = findViewById(R.id.return_button);


        // Set event handlers for each buton on the player
        mPlayPauseButton.setOnClickListener(
                this::onPlayPauseButtonClicked
        );

        mSkipNextButton.setOnClickListener(
            this::onSkipNextButtonClicked
        );

        mSkipPrevButton.setOnClickListener(
                this::onSkipPreviousButtonClicked
        );

        mSeekForwardButton.setOnClickListener(
                this::onSeekForward
        );

        mSeekBackButton.setOnClickListener(
                this::onSeekBack
        );

        mReturnButton.setOnClickListener(
                this::onEndActivityClicked
        );

        mViews =
                Arrays.asList(
                        mReturnButton,
                        mPlayPauseButton,
                        mSeekForwardButton,
                        mSeekBackButton,
                        mSkipPrevButton,
                        mSkipNextButton
                );

        connect(true);
    }

    // Once the return button is pressed, the screen returns to
    // the default (home) screen
    private void onEndActivityClicked(View view) {
        mSecondSpotifyAppRemote // Pauses the music player once the user leaves the page
                .getPlayerApi()
                .pause();

        SpotifyAppRemote.disconnect(mSecondSpotifyAppRemote);
        finish();   // Function used by activities to signal it is over
    }

    @Override
    protected void onStop() {
        super.onStop();
        SpotifyAppRemote.disconnect(mSecondSpotifyAppRemote);
        connect(true);
    }

    private void connect(boolean showAuthView) {

        SpotifyAppRemote.disconnect(mSecondSpotifyAppRemote);

        SpotifyAppRemote.connect(
                getApplicationContext(),
                new ConnectionParams.Builder(CLIENT_ID)
                        .setRedirectUri(REDIRECT_URI)
                        .showAuthView(showAuthView)
                        .build(),
                new Connector.ConnectionListener() {
                    @Override
                    public void onConnected(SpotifyAppRemote spotifyAppRemote) {
                        mSecondSpotifyAppRemote = spotifyAppRemote;
                        updateCoverImage();
                        showCurrentTrack();
                    }

                    @Override
                    public void onFailure(Throwable error) {
                        logError(error);
                        Log.d("error", "ERROR");
                        SecondActivity.this.onStop();
                    }
                });
    }

    // Display the track name and artist of the current song playing
    public void showCurrentTrack() {
        mSecondSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerstate -> {
                            String track = playerstate.track.name;
                            String artist = playerstate.track.artist.name;
                            mPlayerTrack.setText(String.format("Track: %s\nBy: %s", track, artist));
                        }
                );
    }

    // Function to skip a song backwards when the skip button is pressed
    public void onSkipPreviousButtonClicked(View view) {
        mSecondSpotifyAppRemote
                .getPlayerApi()
                .skipPrevious()
                .setResultCallback(
                        empty -> logMessage(getString(R.string.command_feedback, "skip previous")))
                .setErrorCallback(mErrorCallback);
    }

    // Play button that switches between and image of the play button
    // then once paused, switches to the pause button
    public void onPlayPauseButtonClicked(View view) {
        mSecondSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerState -> {
                            if (playerState.isPaused) {
                                int pauseID = this.getResources().getIdentifier("btn_pause", "drawable", this.getPackageName());
                                mPlayPauseButton.setImageResource(pauseID);

                                mSecondSpotifyAppRemote
                                        .getPlayerApi()
                                        .resume()
                                        .setResultCallback(
                                                empty -> logMessage(getString(R.string.command_feedback, "play")))
                                        .setErrorCallback(mErrorCallback);
                            } else {
                                int playID = this.getResources().getIdentifier("btn_play", "drawable", this.getPackageName());
                                mPlayPauseButton.setImageResource(playID);

                                mSecondSpotifyAppRemote
                                        .getPlayerApi()
                                        .pause()
                                        .setResultCallback(
                                                empty -> logMessage(getString(R.string.command_feedback, "pause")))
                                        .setErrorCallback(mErrorCallback);
                            }
                        });
    }

    // Skips the current song being played
    public void onSkipNextButtonClicked(View view) {
        mSecondSpotifyAppRemote
                .getPlayerApi()
                .skipNext()
                .setResultCallback(data -> logMessage(getString(R.string.command_feedback, "skip next")))
                .setErrorCallback(mErrorCallback);

        // Sleeps the program for 2.2 seconds so that the API call
        // to change the album cover can occur
        try {
            Thread.sleep(2200);
            updateCoverImage();
            showCurrentTrack();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Moves the song duration back by 15 seconds
    public void onSeekBack(View view) {
        mSecondSpotifyAppRemote
                .getPlayerApi()
                .seekToRelativePosition(-15000)
                .setResultCallback(data -> logMessage(getString(R.string.command_feedback, "seek back")))
                .setErrorCallback(mErrorCallback);
    }

    // Moves the song duration forward by 15 seconds
    public void onSeekForward(View view) {
        mSecondSpotifyAppRemote
                .getPlayerApi()
                .seekToRelativePosition(15000)
                .setResultCallback(data -> logMessage(getString(R.string.command_feedback, "seek fwd")))
                .setErrorCallback(mErrorCallback);
    }

    // Set the cover image to hte image of the current song playing
    private void updateCoverImage() {
        mSecondSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerstate -> {
                            if (playerstate != null) {
                                mSecondSpotifyAppRemote
                                        .getImagesApi()
                                        .getImage(playerstate.track.imageUri)
                                        .setResultCallback(
                                                bitmap -> mCoverView.setImageBitmap(bitmap)
                                        );
                            }
                        });

        mSecondSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerstate -> System.out.println(playerstate.track.imageUri)
                );
    }

    // Log error functions used from SDK demo program in order to log errors that
    // I would face during the development of the app
    private void logError(Throwable throwable) {
        Toast.makeText(this, R.string.err_generic_toast, Toast.LENGTH_SHORT).show();
        Log.e(TAG, "", throwable);
    }

    private void logMessage(String msg) {
        logMessage(msg, Toast.LENGTH_SHORT);
    }

    private void logMessage(String msg, int duration) {
        Toast.makeText(this, msg, duration).show();
        Log.d(TAG, msg);
    }

    private void showDialog(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).create().show();
    }
}