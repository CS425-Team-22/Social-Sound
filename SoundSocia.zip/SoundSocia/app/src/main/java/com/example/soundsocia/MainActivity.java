package com.example.soundsocia;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import androidx.appcompat.app.AlertDialog;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.spotify.android.appremote.api.ConnectionParams;
import com.spotify.android.appremote.api.Connector;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.protocol.client.ErrorCallback;

public class MainActivity extends FragmentActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    // Global variables used to connect to the Spotify API and Redirect users
    // in case they cannot connect the service
    private static final String CLIENT_ID = "6434a1e4e1f44f328888e90d23a94e92";
    private static final String REDIRECT_URI = "https://com.example.soundsocia/callback/";
    private static final String TRACK_URI = "spotify:track:4PeNQufpxlqjT9g8aIGQFB";     // Hard-coded track uri used for demo purposes
    private static final String COVER_URI = "spotify:image:ab67616d0000b2733b97f1c9a0273bfbdc6bd791";

    private static SpotifyAppRemote mSpotifyAppRemote;  // SpotifyAppRemote class used to access all API methods

    TextView mPlayerStateTrack;     // Text for the track name
    ImageView mCoverArtImageView;   // Image for cover art

    // Buttons for playing music and displaying info about a track
    View mPlayButton;
    View mInfoButton;

    private final ErrorCallback mErrorCallback = this::logError;    // Spotify API log error variable

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Set home page to the activity main xml file

        // Instantiate each app component for editing later
        mCoverArtImageView = findViewById(R.id.image);
        mCoverArtImageView.setVisibility(View.VISIBLE);
        mPlayerStateTrack = findViewById(R.id.current_track);
        mPlayButton = findViewById(R.id.play_button);
        mInfoButton = findViewById(R.id.song_info_button);

        // Set event listeners for the buttons to be clicked
        mPlayButton.setOnClickListener(
                this::onSongTitleClicked);
        mInfoButton.setOnClickListener(
                this::onGetSongInfoClicked);

        SpotifyAppRemote.setDebugMode(true);

        onConnecting();
    }

    // Function to execute when the program is closed
    // This function was taken from the Spotify SDK
    // Demo program that came with the .zip file
    @Override
    protected void onStop() {
        super.onStop();
        mSpotifyAppRemote
                .getPlayerApi()
                .pause();

        SpotifyAppRemote.disconnect(mSpotifyAppRemote);
    }

    // Uses the connect function to connect to Spotify
    private void onConnecting() {
        connect(true);
    }

    private void onDisconnected() {
        SpotifyAppRemote.disconnect(mSpotifyAppRemote);
    }

    // Connects to the Spotify services through the SDK API calls
    // This function was also taken from the Spotify SDK demo program
    private void connect(boolean showAuthView) {

        SpotifyAppRemote.disconnect(mSpotifyAppRemote);

        SpotifyAppRemote.connect(
                getApplicationContext(),
                new ConnectionParams.Builder(CLIENT_ID)
                        .setRedirectUri(REDIRECT_URI)
                        .showAuthView(showAuthView)
                        .build(),
                new Connector.ConnectionListener() {    // Event listener to check when a connection has been established
                    @Override
                    public void onConnected(SpotifyAppRemote spotifyAppRemote) {
                        mSpotifyAppRemote = spotifyAppRemote;   // Instantiate AppRemote when connected
                    }

                    @Override
                    public void onFailure(Throwable error) {    // If connection fails throw an error
                        logError(error);
                        Log.d("error", "ERROR");
                        MainActivity.this.onDisconnected();
                    }
                });
    }

    // Function to play the specific track when the play button is clicked
    public void onSongTitleClicked(View view) {
        playUri(TRACK_URI);

        try {
            Thread.sleep(2500); // Sleeps the program for 2.5 seconds in order for the SDK to process the API call
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Intent is used to switch to the player page after the play button is pressed
        Intent switchActivity = new Intent(this, SecondActivity.class);
        startActivity(switchActivity);
        connect(true);  // Reconnect to Spotify after the other page is returned
    }


    // Function to play a specific track given by the parameter URI
    private void playUri(String uri) {
        mSpotifyAppRemote
                .getPlayerApi()
                .play(uri)
                .setResultCallback(empty -> logMessage(getString(R.string.command_feedback, "play")))
                .setErrorCallback(mErrorCallback);
    }

    // Function to get the info on a song when the info button is clicked
    public void onGetSongInfoClicked(View view) {
        mSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerState -> {    // Default song metadata used for testing
                            String songInfo = "Artist: Anarbor";
                            songInfo += "\nSong Title: Passion For Publication";
                            songInfo += "\nTime Duration: 2:38";

                            showDialog("Song Statistics:", songInfo);   // Create dialog box for user in app
                        }
                )
                .setErrorCallback(mErrorCallback);
    }

    // Log Error functions were taken from the SDK demo program
    // The reason for using these functions was for debugging
    // purposes so that I could understand what functions were
    // behaving incorrecty
    private void logError(Throwable throwable) {
        Toast.makeText(this, R.string.err_generic_toast, Toast.LENGTH_SHORT).show();
        Log.e(TAG, "", throwable);
    }

    private void logMessage(String msg) {
        log(msg);
    }

    private void log(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Log.d(TAG, msg);
    }

    private void showDialog(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).create().show();
    }
}
