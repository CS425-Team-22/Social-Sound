package com.jotreewater.socialsound;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SoundsFragment extends Fragment {

    private final String TAG = "TAGSounds";

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Log.d(TAG,"Sounds Attached");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG,"Sounds Created");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d(TAG,"Sounds View Creating");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG,"Sounds View Created");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG,"Sounds Started");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG,"Sounds Resumed");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG,"Sounds Paused");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG,"Sounds Stopped");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG,"Sounds Destroyed");
    }
}
