package com.jotreewater.socialsound;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.spotify.android.appremote.api.ImagesApi;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.protocol.client.CallResult;
import com.spotify.protocol.types.ImageIdentifier;
import com.spotify.protocol.types.ImageUri;

import java.io.InputStream;
import java.net.URL;

import io.paperdb.Paper;

public class ProfileFragment extends Fragment {
    private final String TAG = "TAGProfile";
    Context profileFragmentContext;

    TextView textViewUsername, textViewLocation, textViewTrackName;
    ImageView imageViewTrackImage;
    Button buttonLogout;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference reference = database.getReference().child("Users");

    @Override
    public void onAttach(@NonNull Context context) {
        Log.d(TAG, "Profile Attached");
        super.onAttach(context);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "Profile Created");
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        profileFragmentContext = container.getContext();
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "Profile ViewCreated");
        super.onViewCreated(view, savedInstanceState);

        // get variables and functions from main activity
        MainActivity mainActivity = (MainActivity) getActivity();

        // textViewUsername

        textViewUsername = getActivity().findViewById(R.id.textViewUsername);
        Log.d(TAG, "Username: " + mainActivity.username);

        textViewUsername.setText(mainActivity.username);

        // textViewTrackName
        textViewTrackName = getActivity().findViewById(R.id.textViewTrackName);
        textViewTrackName.setText(mainActivity.trackName);

        // imageViewTrackImage
        imageViewTrackImage = getActivity().findViewById(R.id.imageViewTrackImage);

        if (mainActivity.trackImage != null) {
            Log.d(TAG, "TrackImage URI: " + mainActivity.trackImage);

            ImageUri imageUri = new ImageUri(mainActivity.trackImage);

            Log.d(TAG, "ImageURI: " + imageUri.toString());

            mainActivity.mainSpotifyAppRemote.getImagesApi().getImage(imageUri).setResultCallback(new CallResult.ResultCallback<Bitmap>() {
                @Override
                public void onResult(Bitmap data) {
                    imageViewTrackImage.setImageBitmap(data);
                }
            });
        }

        // buttonLogout

        buttonLogout = getActivity().findViewById(R.id.buttonLogout);
        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //remove remember me so the user isn't forcibly logged in again
                Paper.book().destroy();

                //return to to login activity
                getParentFragmentManager().beginTransaction().replace(R.id.fragmentContainerView,LoginFragment.class,null).commitNow();
                mainActivity.buttonPlayer.setVisibility(View.GONE);
                reference.child(mainActivity.auth.getUid()).child("lon").setValue(0);
                reference.child(mainActivity.auth.getUid()).child("lat").setValue(0);
                mainActivity.auth = null;
                mainActivity.buttonProfile.setVisibility(View.GONE);
                mainActivity.buttonSounds.setVisibility(View.GONE);
                SpotifyAppRemote.disconnect(mainActivity.mainSpotifyAppRemote);
                Log.d(TAG, "=== Remember Me information Cleared. ===");
            }
        });

        //textViewLocation

        textViewLocation = getActivity().findViewById(R.id.textViewLocation);
        Log.d(TAG, mainActivity.location_string);
        textViewLocation.setText(mainActivity.location_string);

    }

    @Override
    public void onStart() {
        Log.d(TAG, "Profile Started");
        super.onStart();
    }

    @Override
    public void onResume() {
        Log.d(TAG, "Profile Resumed");
        super.onResume();
    }

    @Override
    public void onPause() {
        Log.d(TAG, "Profile Paused");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.d(TAG, "Profile Stopped");
        super.onStop();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "Profile Destroyed");
        super.onDestroy();
    }

}
