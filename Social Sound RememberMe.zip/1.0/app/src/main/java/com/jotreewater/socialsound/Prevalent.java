package com.jotreewater.socialsound;

import com.jotreewater.socialsound.User;

public class Prevalent {
    public static User currentUser;

    public static final String userEmail = "userEmail";
    public static final String userPassword = "userPassword";
}
