package com.jotreewater.socialsound;

public class SongnodeFragment extends MainActivity {

    private String song_name;
    private String song_uri;
    private String artist_album_name;
    private String shared_user_name;
    private String album_art;

    // Constructor
    public SongnodeFragment(String song_name, String artist_album_name, String shared_user_name, String song_uri, String album_art) {
        this.song_name = song_name;
        this.artist_album_name = artist_album_name;
        this.shared_user_name = shared_user_name;
        this.song_uri = song_uri;
        this.album_art = album_art;
    }

    // Getter and Setter
    public String getSong_name() {
        return song_name;
    }

    public void setSong_name(String song_name) {
        this.song_name = song_name;
    }

    public String getSong_uri() {return song_uri; }

    public void setSong_uri(String uri) { this.song_uri = uri; }

    public String getArtist_name() {
        return artist_album_name;
    }

    public void setArtist_name(String artist_album_name) {
        this.artist_album_name = artist_album_name;
    }

    public String getUser_name() {
        return shared_user_name;
    }

    public void setUser_name(String shared_user_name) {
        this.shared_user_name = shared_user_name;
    }

    public String getAlbum_art() {
        return album_art;
    }

    public void setAlbum_art(String album_art) {
        this.album_art = album_art;
    }
}
