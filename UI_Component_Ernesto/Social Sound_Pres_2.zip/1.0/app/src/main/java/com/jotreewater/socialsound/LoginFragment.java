package com.jotreewater.socialsound;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginFragment extends Fragment {

    private final String TAG = "TAGLogin";

    // View Variables
    public TextInputEditText editTextEmail, editTextPassword;
    public Button buttonLogin;
    public Button buttonRegister;

    FirebaseAuth auth;

    // Toast context variable
    Context loginFragmentContext;

    @Override
    public void onAttach(@NonNull Context context) {
        Log.d(TAG, "Login Attached");
        super.onAttach(context);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "Login Created");
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        loginFragmentContext = container.getContext();
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "Login ViewCreated");
        super.onViewCreated(view, savedInstanceState);
        auth = FirebaseAuth.getInstance();

        // editText's

        editTextEmail = getActivity().findViewById(R.id.editTextEmail);
        editTextPassword = getActivity().findViewById(R.id.editTextPassword);

        // buttonLogin
        buttonLogin = getActivity().findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "buttonLogin pressed");
                String email = editTextEmail.getText().toString();
                String password = editTextPassword.getText().toString();
                if(!email.equals("") && !password.equals(""))
                {
                    signin(email,password);
                }
                else
                {
                    Toast.makeText(loginFragmentContext,"Please enter a username and password",Toast.LENGTH_SHORT).show();
                }
            }
        });

        // buttonRegister

        buttonRegister = getActivity().findViewById(R.id.buttonRegister);
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "buttonRegister pressed");
                getParentFragmentManager().beginTransaction().replace(R.id.fragmentContainerView,RegisterFragment.class,null).commitNow();
            }
        });
    }

    // FirebaseAuth
    public void signin(String email, String password) {
        Log.d(TAG, "Email: " + email);
        Log.d(TAG, "Password: " + password);
        auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(loginFragmentContext,"Successful login",Toast.LENGTH_SHORT).show();
                    MainActivity mainActivity = (MainActivity) getActivity();
                    mainActivity.takeData(auth);
                }
                else
                {
                    Toast.makeText(loginFragmentContext,"Login failed, try again",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onStart() {
        Log.d(TAG, "Login Started");
        super.onStart();
    }

    @Override
    public void onResume() {
        Log.d(TAG, "Login Resumed");
        super.onResume();
    }

    @Override
    public void onPause() {
        Log.d(TAG, "Login Paused");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.d(TAG, "Login Stopped");
        super.onStop();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "Login Destroyed");
        super.onDestroy();
    }
}