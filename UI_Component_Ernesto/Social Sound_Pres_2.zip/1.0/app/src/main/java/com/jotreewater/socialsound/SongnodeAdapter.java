package com.jotreewater.socialsound;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SongnodeAdapter extends RecyclerView.Adapter<SongnodeAdapter.Viewholder>{
    private Context context;
    private ArrayList<SongnodeFragment> courseModelArrayList;
    private OnItemClickListener mClickListener;
    private CardView cardView;

    public interface OnItemClickListener {
        void onItemClick(int position);
        void onAddClick();
        void onMenuClick();
    }

    // Constructor
    public SongnodeAdapter(Context context, ArrayList<SongnodeFragment> courseModelArrayList) {
        this.context = context;
        this.courseModelArrayList = courseModelArrayList;
    }

    @NonNull
    @Override
    public SongnodeAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // to inflate the layout for each item of recycler view.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.song_layout, parent, false);
        return new Viewholder(view, mClickListener);
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        mClickListener = listener;
    }

    public void getImage(ImageView iview) {
        MainActivity.mSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerstate -> {
                            if (playerstate != null) {
                                MainActivity.mSpotifyAppRemote
                                        .getImagesApi()
                                        .getImage(playerstate.track.imageUri)
                                        .setResultCallback(
                                                bitmap -> iview.setImageBitmap(bitmap)
                                        );
                            }
                        });
    }

    @Override
    public void onBindViewHolder(@NonNull SongnodeAdapter.Viewholder holder, int position) {
        // to set data to textview and imageview of each card layout
        SongnodeFragment model = courseModelArrayList.get(position);
        holder.songName.setText(model.getSong_name());
        holder.artistName.setText(model.getArtist_name());
        holder.userName.setText(model.getUser_name());
        //holder.albumArt.setImageResource(model.getAlbum_art());
        getImage(holder.albumArt);
        //holder.albumArt.setImageBitmap(model.getAlbum_art());
    }

    @Override
    public int getItemCount() {
        // this method is used for showing number
        // of card items in recycler view.
        return courseModelArrayList.size();
    }

    // View holder class for initializing of
    // your views such as TextView and Imageview.
    public class Viewholder extends RecyclerView.ViewHolder {
        private ImageView albumArt ;
        private TextView songName, artistName, userName;
        private ImageButton likeButton, addButton, menuButton;
        boolean liked = true;

        public Viewholder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            albumArt = itemView.findViewById(R.id.album_art);
            songName = itemView.findViewById(R.id.song_title);
            artistName = itemView.findViewById(R.id.artist_album_name);
            userName = itemView.findViewById(R.id.shared_user_name);
            likeButton = itemView.findViewById((R.id.like_button));
            addButton = itemView.findViewById((R.id.playlist_button));
            menuButton = itemView.findViewById((R.id.menu_button));

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(getAdapterPosition());
                }
            });

            likeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(liked) {
                        likeButton.setImageResource(R.drawable.ic_like_filled);
                        liked = false;
                    }
                    else {
                        likeButton.setImageResource(R.drawable.ic_like);
                        liked = true;
                    }
                }
            });

            addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onAddClick();
                }
            });

            menuButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onMenuClick();
                }
            });
        }
    }
}
