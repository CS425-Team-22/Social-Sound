package com.jotreewater.socialsound;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.spotify.android.appremote.api.AppRemote;
import com.spotify.android.appremote.api.ConnectionParams;
import com.spotify.android.appremote.api.Connector;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.protocol.client.ErrorCallback;
import com.spotify.protocol.types.ImageUri;
import com.spotify.protocol.types.Track;

public class MainActivity extends AppCompatActivity {

    public static AppRemote mSpotifyAppRemote;
    private final String TAG = "TAGMain";

    // Firebase variables
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    FirebaseDatabase database;

    // Spotify variables
    private static final String CLIENT_ID = "6434a1e4e1f44f328888e90d23a94e92";
    private static final String REDIRECT_URI = "http://com.jotreewater.socialsound/callback";
    private static final int REQUEST_CODE = 1337;
    public SpotifyAppRemote mainSpotifyAppRemote;

    // Location variables
    LocationManager locationManager;
    LocationListener locationListener;
    double lat,lon;
    String location_string = "[0,0]";

    // Auth variables
    public String username = "Username";

    //Spotify variables
    public String trackName;
    public String trackImage;
    ErrorCallback mErrorCallback;

    // activity_main variables
    Button buttonProfile;
    Button buttonSounds;
    Button buttonPlayer;

    // Happens first, happens once
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "Main Created");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // buttonProfile
        buttonProfile = findViewById(R.id.buttonProfile);

        if(auth == null)
        {
            buttonProfile.setVisibility(View.GONE);
        }

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (auth != null) {
                    Log.d(TAG, "buttonProfile pressed");
                    ProfileFragment profileFragment = new ProfileFragment();
                    Fragment previous_fragment = getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
                    getSupportFragmentManager().beginTransaction().remove(previous_fragment).commitNow();
                    getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainerView,profileFragment).commitNow();
                }
            }
        });

        //buttonSounds
        buttonSounds = findViewById(R.id.buttonSounds);
        buttonPlayer = findViewById(R.id.buttonPlayer);

        if(auth == null)
        {
            buttonSounds.setVisibility(View.GONE);
        }

        buttonSounds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(auth!=null)
                {
                    Log.d(TAG, "buttonSounds pressed");
                    SoundsFragment soundsFragment = new SoundsFragment();
                    Fragment previous_fragment = getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
                    getSupportFragmentManager().beginTransaction().remove(previous_fragment).commitNow();
                    getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainerView,soundsFragment).commitNow();
                }
            }
        });

        if(auth == null)
        {
            buttonPlayer.setVisibility(View.GONE);
        }

        buttonPlayer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(auth!=null)
                {
                    Log.d(TAG, "buttonPlayer pressed");
                    PlayerFragment playerFragment = new PlayerFragment();
                    Fragment previous_fragment = getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
                    getSupportFragmentManager().beginTransaction().remove(previous_fragment).commitNow();
                    getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainerView,playerFragment).commitNow();
                }
            }
        });


        // Check if the user needs to log in

        if (auth == null) {
            Log.d(TAG, "No UID found, starting LoginFragment");
            FragmentManager loginFragmentManager = getSupportFragmentManager();
            //FragmentTransaction loginFragmentTransaction = loginFragmentManager.beginTransaction();
            LoginFragment loginFragment = new LoginFragment();
            loginFragmentManager.beginTransaction().add(R.id.fragmentContainerView,loginFragment).commitNow();
            //loginFragmentTransaction.commitNow();
        }
    }

    public void takeData(FirebaseAuth login_auth)
    {
        auth = login_auth;
        user = auth.getCurrentUser();
        database = FirebaseDatabase.getInstance();
        reference = database.getReference().child("Users").child(user.getUid());

        reference.child("username").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Get username
                username = (String) snapshot.getValue();
                Log.d(TAG, "Username: " + username);

                // Get Location
                initializeLocationService();

                // Reveal navbar
                buttonProfile.setVisibility(View.VISIBLE);
                buttonSounds.setVisibility(View.VISIBLE);
                buttonPlayer.setVisibility(View.VISIBLE);

                // Spotify
                initializeSpotifyService();

                // Switch to Profile Fragment
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, ProfileFragment.class, null).commit();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void initializeLocationService(){

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                lon = location.getLongitude();
                lat = location.getLatitude();
                location_string = "[" + lon + ", " + lat + "]";
                Log.d(TAG, "Location lon: " + lon);
                Log.d(TAG, "Location lat: " + lat);

                reference.child("lon").setValue(lon);
                reference.child("lat").setValue(lat);
            }
        };

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
        }
        else{
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,500,50,locationListener);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == 1 && permissions.length > 0 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
        {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 50, locationListener);
        }

    }

    public void initializeSpotifyService() {
        ConnectionParams connectionParams =
                new ConnectionParams.Builder(CLIENT_ID)
                        .setRedirectUri(REDIRECT_URI)
                        .showAuthView(true)
                        .build();

        SpotifyAppRemote.disconnect(mainSpotifyAppRemote);
        SpotifyAppRemote.connect(this, connectionParams, new Connector.ConnectionListener() {
            @Override
            public void onConnected(SpotifyAppRemote spotifyAppRemote) {
                mainSpotifyAppRemote = spotifyAppRemote;
                Log.d(TAG, "Spotify Connected");

                mainSpotifyAppRemote.getPlayerApi()
                        .subscribeToPlayerState()
                        .setEventCallback(playerState -> {

                            final Track track = playerState.track;
                            if (track != null) {
                                Log.d(TAG, track.name + " by " + track.artist.name);

                                // Push track to Firebase
                                reference.child("trackName").setValue(track.name);
                                reference.child("trackImage").setValue(track.imageUri.toString());

                            }

                        });

                // Pull track from Firebase
                reference.child("trackName").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        trackName = (String) snapshot.getValue();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

                // Pull image uri from Firebase
                reference.child("trackImage").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        trackImage = snapshot.getValue().toString();
                        trackImage = trackImage.substring(8,trackImage.length() - 2);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }

            @Override
            public void onFailure(Throwable error) {
                Log.d(TAG, "Spotify failed to connect: " + error);
            }
        });
    }

    // Happens whenever the activity is opened
    @Override
    protected void onStart() {
        Log.d(TAG, "Main Started");
        super.onStart();
    }

    // Happens whenever the activity is closed
    @Override
    protected void onStop() {
        Log.d(TAG, "Main Stopped");
        super.onStop();
    }

    // Happens when configuration changes
    @Override
    protected void onDestroy() {
        Log.d(TAG, "Main Destroyed");
        super.onDestroy();
        reference.child("lon").setValue(0);
        reference.child("lat").setValue(0);
    }
}