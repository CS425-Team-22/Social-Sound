package com.example.social_sound.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.social_sound.MainActivity;
import com.example.social_sound.R;
import com.example.social_sound.databinding.FragmentHomeBinding;
import com.example.social_sound.databinding.FragmentSonglistBinding;
import com.example.social_sound.ui.homepage_test.SongnodeAdapter;
import com.example.social_sound.ui.homepage_test.SongnodeFragment;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.protocol.client.ErrorCallback;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentSonglistBinding binding;

    private RecyclerView songListRV;
    // Arraylist for storing data
    private ArrayList<SongnodeFragment> courseModelArrayList;
    private SongnodeAdapter songnodeAdapter;
    //public static SpotifyAppRemote mSpotifyAppRemote;
    public final ErrorCallback mErrorCallback = this::logError;
    private static final String TAG = MainActivity.class.getSimpleName();




    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ((MainActivity)getActivity()).onConnecting();
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentSonglistBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //*****************************************************************************************
        //  Ernesto Bernardo HomeFragment.java
        //  File and functionality created with Android Studio Template
        //  ImageButton variable and setOnClickListener functions created by Ernesto Bernardo
        //*****************************************************************************************
        songListRV = root.findViewById(R.id.songList);

        // here we have created new array list and added data to it.
        courseModelArrayList = new ArrayList<>();
        courseModelArrayList.add(new SongnodeFragment("On Melancholy Hill", "Gorillaz - Plastic Beach", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("AAA Powerline", "Ecco2k - E", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("I've Wasted So Much Time", "Enjoy - Deep Cuts", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("1539 N. Calvert", "JPEGMAFIA - Veteran", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("D.A.N.C.E.", "Justice - Justice", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("CALLIGRAPHY", "Saba - CARE FOR ME", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("Chamber of Reflection", "Mac DeMarco - Salad Days", "Shared by Ernesto B.", R.drawable.ic_like));

        // we are initializing our adapter class and passing our arraylist to it.
        songnodeAdapter = new SongnodeAdapter(this.getContext(), courseModelArrayList);


        // below line is for setting a layout manager for our recycler view.
        // here we are creating vertical list so we will provide orientation as vertical
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getContext(), LinearLayoutManager.VERTICAL, false);

        // in below two lines we are setting layoutmanager and adapter to our recycler view.
        songListRV.setLayoutManager(linearLayoutManager);
        //songListRV.setOnClickListener(this);
        songListRV.setAdapter(songnodeAdapter);
        songnodeAdapter.setOnItemClickListener(new SongnodeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                String uri = courseModelArrayList.get(position).getSong_uri();
                playUri(uri);
            }

            @Override
            public void onAddClick() {
                ((MainActivity)getActivity()).displayPlaylist();
            }
        });

        return root;
    }


    public Context getContext(){
        return (MainActivity) getActivity();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    // Function to play a specific track given by the parameter URI
    private void playUri(String uri) {
        ((MainActivity)getActivity()).mSpotifyAppRemote
                .getPlayerApi()
                .play(uri)
                .setErrorCallback(mErrorCallback);
    }

    // Log Error functions were taken from the SDK demo program
    // The reason for using these functions was for debugging
    // purposes so that I could understand what functions were
    // behaving incorrecty
    private void logError(Throwable throwable) {
        Toast.makeText(getActivity(), R.string.err_generic_toast, Toast.LENGTH_SHORT).show();
        Log.e(TAG, "", throwable);
    }
}