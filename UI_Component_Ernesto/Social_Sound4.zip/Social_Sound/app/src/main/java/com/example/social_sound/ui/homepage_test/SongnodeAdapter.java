package com.example.social_sound.ui.homepage_test;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.social_sound.R;

import java.util.ArrayList;

public class SongnodeAdapter extends RecyclerView.Adapter<SongnodeAdapter.Viewholder>{
    private Context context;
    private ArrayList<SongnodeFragment> courseModelArrayList;

    // Constructor
    public SongnodeAdapter(Context context, ArrayList<SongnodeFragment> courseModelArrayList) {
        this.context = context;
        this.courseModelArrayList = courseModelArrayList;
    }

    @NonNull
    @Override
    public SongnodeAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // to inflate the layout for each item of recycler view.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.song_layout, parent, false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SongnodeAdapter.Viewholder holder, int position) {
        // to set data to textview and imageview of each card layout
        SongnodeFragment model = courseModelArrayList.get(position);
        holder.songName.setText(model.getSong_name());
        holder.artistName.setText(model.getArtist_name());
        holder.userName.setText(model.getUser_name());
        holder.albumArt.setImageResource(model.getAlbum_art());
    }

    @Override
    public int getItemCount() {
        // this method is used for showing number
        // of card items in recycler view.
        return courseModelArrayList.size();
    }

    // View holder class for initializing of
    // your views such as TextView and Imageview.
    public class Viewholder extends RecyclerView.ViewHolder {
        private ImageView albumArt ;
        private TextView songName, artistName, userName;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            albumArt = itemView.findViewById(R.id.album_art);
            songName = itemView.findViewById(R.id.song_title);
            artistName = itemView.findViewById(R.id.artist_album_name);
            userName = itemView.findViewById(R.id.shared_user_name);
        }
    }
}
