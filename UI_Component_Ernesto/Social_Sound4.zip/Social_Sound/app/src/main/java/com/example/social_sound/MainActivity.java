package com.example.social_sound;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import com.example.social_sound.ui.create_profile.CreateFragment;
import com.example.social_sound.ui.homepage_test.SonglistFragment;
import com.example.social_sound.ui.login.LoginFragment;
import com.example.social_sound.ui.playlist.PlaylistFragment;
import com.example.social_sound.ui.profile.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.social_sound.databinding.ActivityMainBinding;

import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.android.appremote.api.ConnectionParams;
import com.spotify.android.appremote.api.Connector;
import com.spotify.protocol.client.ErrorCallback;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private ActivityMainBinding binding;
    private ProfileFragment profile_fragment;
    private CreateFragment create_fragment;
    private LoginFragment login_fragment;
    private PlaylistFragment playlist_fragment;
    private SonglistFragment homepage_fragment;
    public static SpotifyAppRemote mSpotifyAppRemote;
    public final ErrorCallback mErrorCallback = this::logError;
    public AppCompatImageButton mPlayPauseButton;
    public TextView mPlayerTrack;
    public ImageView mCoverView;


    private static final String CLIENT_ID = "6434a1e4e1f44f328888e90d23a94e92";
    private static final String REDIRECT_URI = "https://com.example.soundsocia/callback/";
    private static final String TRACK_URI = "spotify:track:4PeNQufpxlqjT9g8aIGQFB";     // Hard-coded track uri used for demo purposes
    private static final String COVER_URI = "spotify:image:ab67616d0000b2733b97f1c9a0273bfbdc6bd791";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //mPlayPauseButton = (AppCompatImageButton) findViewById(R.id.play_pause_button);
        //mPlayerTrack = (TextView) findViewById(R.id.current_track_label);
        //mCoverView = (ImageButton) findViewById(R.id.image);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);
        //*****************************************************************************************
        //  Ernesto Bernardo MainActivity.java
        //  MainActivity.java and functionality created with Android Studio Template
        //  X_fragment variables and displayX() and closeX() functions created by Ernesto Bernardo
        //*****************************************************************************************
        profile_fragment = new ProfileFragment();
        create_fragment = new CreateFragment();
        login_fragment = new LoginFragment();
        playlist_fragment = new PlaylistFragment();
        homepage_fragment = new SonglistFragment();
        onConnecting();
    }

    public void displayProfile(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.nav_host_fragment_activity_main, profile_fragment);
        ft.commit();
    }

    public void closeProfile(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.remove(profile_fragment);
        ft.commit();
    }

    public void displayCreate(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.nav_host_fragment_activity_main, create_fragment);
        ft.commit();
    }

    public void closeCreate(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.remove(create_fragment);
        ft.commit();
    }

    public void displayLogin(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.nav_host_fragment_activity_main, login_fragment);
        ft.commit();
    }

    public void closeLogin(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.remove(login_fragment);
        ft.commit();
    }

    public void displayPlaylist(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.nav_host_fragment_activity_main, playlist_fragment);
        ft.commit();
    }

    public void closePlaylist(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.remove(playlist_fragment);
        ft.commit();
    }

    public void displayHomepage(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.nav_host_fragment_activity_main, homepage_fragment);
        ft.commit();
    }

    public void closeHomepage(){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.remove(homepage_fragment);
        ft.commit();
    }

    // Uses the connect function to connect to Spotify
    public void onConnecting() {
        connect(true);
    }

    public void onDisconnected() {
        SpotifyAppRemote.disconnect(mSpotifyAppRemote);
    }

    // Connects to the Spotify services through the SDK API calls
    // This function was also taken from the Spotify SDK demo program
    private void connect(boolean showAuthView) {

        SpotifyAppRemote.disconnect(mSpotifyAppRemote);

        SpotifyAppRemote.connect(
                getApplicationContext(),
                new ConnectionParams.Builder(CLIENT_ID)
                        .setRedirectUri(REDIRECT_URI)
                        .showAuthView(showAuthView)
                        .build(),
                new Connector.ConnectionListener() {    // Event listener to check when a connection has been established
                    @Override
                    public void onConnected(SpotifyAppRemote spotifyAppRemote) {
                        mSpotifyAppRemote = spotifyAppRemote;   // Instantiate AppRemote when connected
                    }

                    @Override
                    public void onFailure(Throwable error) {    // If connection fails throw an error
                        logError(error);
                        Log.d("error", "ERROR");
                        onDisconnected();
                    }
                });
    }

    // Function to play the specific track when the play button is clicked
    public void onSongTitleClicked() {
        playUri(TRACK_URI);

        try {
            Thread.sleep(2500); // Sleeps the program for 2.5 seconds in order for the SDK to process the API call
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    // Function to play a specific track given by the parameter URI
    private void playUri(String uri) {
        mSpotifyAppRemote
                .getPlayerApi()
                .play(uri)
                .setErrorCallback(mErrorCallback);
    }

    // Log Error functions were taken from the SDK demo program
    // The reason for using these functions was for debugging
    // purposes so that I could understand what functions were
    // behaving incorrecty
    private void logError(Throwable throwable) {
        Toast.makeText(this, R.string.err_generic_toast, Toast.LENGTH_SHORT).show();
        Log.e(TAG, "", throwable);
    }

    private void logMessage(String msg) {
        log(msg);
    }

    private void log(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Log.d(TAG, msg);
    }

    private void showDialog(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).create().show();
    }

    // Play button that switches between and image of the play button
    // then once paused, switches to the pause button
    public void onPlayPauseButtonClicked() {
        updateCoverImage();
        showCurrentTrack();
        mPlayPauseButton = (AppCompatImageButton) findViewById(R.id.play_pause_button);
        mSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerState -> {
                            if (playerState.isPaused) {
                                int pauseID = this.getResources().getIdentifier("btn_pause", "drawable", this.getPackageName());
                                mPlayPauseButton.setImageResource(pauseID);

                                mSpotifyAppRemote
                                        .getPlayerApi()
                                        .resume()
                                        .setResultCallback(
                                                empty -> logMessage(getString(R.string.command_feedback, "play")))
                                        .setErrorCallback(mErrorCallback);
                            } else {
                                int playID = this.getResources().getIdentifier("btn_play", "drawable", this.getPackageName());
                                mPlayPauseButton.setImageResource(playID);

                                mSpotifyAppRemote
                                        .getPlayerApi()
                                        .pause()
                                        .setResultCallback(
                                                empty -> logMessage(getString(R.string.command_feedback, "pause")))
                                        .setErrorCallback(mErrorCallback);
                            }
                        });
    }

    // Function to skip a song backwards when the skip button is pressed
    public void onSkipPreviousButtonClicked() {
        mSpotifyAppRemote
                .getPlayerApi()
                .skipPrevious()
                .setResultCallback(
                        empty -> logMessage(getString(R.string.command_feedback, "skip previous")))
                .setErrorCallback(mErrorCallback);

        // Sleeps the program for 2.2 seconds so that the API call
        // to change the album cover can occur
        try {
            Thread.sleep(2200);
            updateCoverImage();
            showCurrentTrack();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Skips the current song being played
    public void onSkipNextButtonClicked() {
        mSpotifyAppRemote
                .getPlayerApi()
                .skipNext()
                .setResultCallback(data -> logMessage(getString(R.string.command_feedback, "skip next")))
                .setErrorCallback(mErrorCallback);

        // Sleeps the program for 2.2 seconds so that the API call
        // to change the album cover can occur
        try {
            Thread.sleep(2200);
            updateCoverImage();
            showCurrentTrack();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Moves the song duration back by 15 seconds
    public void onSeekBack() {
        mSpotifyAppRemote
                .getPlayerApi()
                .seekToRelativePosition(-15000)
                .setResultCallback(data -> logMessage(getString(R.string.command_feedback, "seek back")))
                .setErrorCallback(mErrorCallback);
    }

    // Moves the song duration forward by 15 seconds
    public void onSeekForward() {
        mSpotifyAppRemote
                .getPlayerApi()
                .seekToRelativePosition(15000)
                .setResultCallback(data -> logMessage(getString(R.string.command_feedback, "seek fwd")))
                .setErrorCallback(mErrorCallback);
    }

    // Set the cover image to hte image of the current song playing
    public void updateCoverImage() {
        mCoverView = (AppCompatImageView) findViewById(R.id.image);
        mSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerstate -> {
                            if (playerstate != null) {
                                mSpotifyAppRemote
                                        .getImagesApi()
                                        .getImage(playerstate.track.imageUri)
                                        .setResultCallback(
                                                bitmap -> mCoverView.setImageBitmap(bitmap)
                                        );
                            }
                        });

        mSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerstate -> System.out.println(playerstate.track.imageUri)
                );
    }

    // Display the track name and artist of the current song playing
    public void showCurrentTrack() {
        mPlayerTrack = (TextView) findViewById(R.id.current_track_label);
        mSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerstate -> {
                            String track = playerstate.track.name;
                            String artist = playerstate.track.artist.name;
                            mPlayerTrack.setText(String.format("Track: %s\nBy: %s", track, artist));
                        }
                );
    }
}