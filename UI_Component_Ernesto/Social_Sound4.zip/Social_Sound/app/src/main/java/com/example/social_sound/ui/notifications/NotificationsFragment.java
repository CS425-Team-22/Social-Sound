package com.example.social_sound.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.social_sound.MainActivity;
import com.example.social_sound.R;
import com.example.social_sound.databinding.FragmentNotificationsBinding;

import java.util.Objects;

public class NotificationsFragment extends Fragment {
    //*****************************************************************************************
    //  Ernesto Bernardo NotificationsFragment.java
    //  File and functionality created with Android Studio Template
    //  Nothing created or changed by Ernesto Bernardo
    //*****************************************************************************************
    private NotificationsViewModel notificationsViewModel;
    private FragmentNotificationsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                new ViewModelProvider(this).get(NotificationsViewModel.class);

        binding = FragmentNotificationsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textNotifications;
        notificationsViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });

        //*****************************************************************************************
        //  Ernesto Bernardo NotificationsFragment.java
        //  File and functionality created with Android Studio Template
        //  ImageButton variable and setOnClickListener functions created by Ernesto Bernardo
        //*****************************************************************************************
        //AppCompatImageButton PlayPauseButton = ((MainActivity)getActivity()).mPlayPauseButton;
        AppCompatImageButton PlayPauseButton = (AppCompatImageButton) root.findViewById(R.id.play_pause_button);
        AppCompatImageButton SkipNextButton = (AppCompatImageButton) root.findViewById(R.id.skip_next_button);
        AppCompatImageButton SkipPrevButton = (AppCompatImageButton) root.findViewById(R.id.skip_prev_button);
        AppCompatImageButton SeekForwardButton = (AppCompatImageButton) root.findViewById(R.id.seek_forward_button);
        AppCompatImageButton SeekBackButton = (AppCompatImageButton) root.findViewById(R.id.seek_back_button);

        PlayPauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).onPlayPauseButtonClicked();
            }
        });

        SkipNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).onSkipNextButtonClicked();
            }
        });

        SkipPrevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).onSkipPreviousButtonClicked();
            }
        });

        SeekForwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).onSeekForward();
            }
        });

        SeekBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).onSeekBack();
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}