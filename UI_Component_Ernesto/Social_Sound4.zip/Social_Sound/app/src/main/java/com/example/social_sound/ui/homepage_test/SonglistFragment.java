package com.example.social_sound.ui.homepage_test;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

import androidx.fragment.app.Fragment;

import com.example.social_sound.MainActivity;
import com.example.social_sound.R;


public class SonglistFragment extends Fragment{
    private RecyclerView songListRV;

    // Arraylist for storing data
    private ArrayList<SongnodeFragment> courseModelArrayList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstaceState){
        View view = inflater.inflate(R.layout.fragment_songlist, parent, false);
        songListRV = view.findViewById(R.id.songList);


        // here we have created new array list and added data to it.
        courseModelArrayList = new ArrayList<>();
        courseModelArrayList.add(new SongnodeFragment("On Melancholy Hill", "Gorillaz - Plastic Beach", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("AAA Powerline", "Ecco2k - E", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("I've Wasted So Much Time", "Enjoy - Deep Cuts", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("1539 N. Calvert", "JPEGMAFIA - Veteran", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("D.A.N.C.E.", "Justice - Justice", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("CALLIGRAPHY", "Saba - CARE FOR ME", "Shared by Ernesto B.", R.drawable.ic_like));
        courseModelArrayList.add(new SongnodeFragment("Chamber of Reflection", "Mac DeMarco - Salad Days", "Shared by Ernesto B.", R.drawable.ic_like));

        // we are initializing our adapter class and passing our arraylist to it.
        SongnodeAdapter SongnodeAdapter = new SongnodeAdapter(this.getContext(), courseModelArrayList);

        // below line is for setting a layout manager for our recycler view.
        // here we are creating vertical list so we will provide orientation as vertical
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getContext(), LinearLayoutManager.VERTICAL, false);

        // in below two lines we are setting layoutmanager and adapter to our recycler view.
        songListRV.setLayoutManager(linearLayoutManager);
        songListRV.setAdapter(SongnodeAdapter);

        return view;
    }
}
