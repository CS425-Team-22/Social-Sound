package com.jotreewater.socialsound;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterFragment extends Fragment {

    private final String TAG = "TAGRegister";
    Context registerFragmentContext = null;

    public Button buttonRegister2;
    public TextInputEditText editTextRegisterEmail, editTextRegisterPassword, editTextRegisterUsername;

    FirebaseAuth auth;
    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    public void onAttach(@NonNull Context context) {
        Log.d(TAG, "Register Attached");
        super.onAttach(context);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "Register Created");
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        registerFragmentContext = container.getContext();
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "Register ViewCreated");
        super.onViewCreated(view, savedInstanceState);

        buttonRegister2 = getActivity().findViewById(R.id.buttonRegister2);
        editTextRegisterEmail = getActivity().findViewById(R.id.editTextRegisterEmail);
        editTextRegisterPassword = getActivity().findViewById(R.id.editTextRegisterPassword);
        editTextRegisterUsername = getActivity().findViewById(R.id.editTextRegisterUsername);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        reference = database.getReference();

        // buttonRegister2

        buttonRegister2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "buttonRegister2 pressed");

                String email = editTextRegisterEmail.getText().toString();
                String password = editTextRegisterPassword.getText().toString();
                String username = editTextRegisterUsername.getText().toString();

                if(!email.equals("") && !password.equals("") && !username.equals(""))
                {
                    register(email,password,username);
                }
                else
                {
                    Toast.makeText(registerFragmentContext,"Please enter the correct authentication",Toast.LENGTH_SHORT).show();
                }
            }
        });

        // backButtonBehavior

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Log.d(TAG, "Back pressed");
                getParentFragmentManager().beginTransaction().replace(R.id.fragmentContainerView,LoginFragment.class,null).commitNow();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), callback);

    }

    public void register(String email,String password,String username)
    {
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    reference.child("Users").child(auth.getUid()).child("username").setValue(username);
                    getParentFragmentManager().beginTransaction().replace(R.id.fragmentContainerView,LoginFragment.class,null).commitNow();
                }
                else
                {
                    Log.d(TAG, task.getException().toString());
                    Toast.makeText(registerFragmentContext,"Registration failed, please try again",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onStart() {
        Log.d(TAG, "Register Started");
        super.onStart();
    }

    @Override
    public void onResume() {
        Log.d(TAG, "Register Resumed");
        super.onResume();
    }

    @Override
    public void onPause() {
        Log.d(TAG, "Register Paused");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.d(TAG, "Register Stopped");
        super.onStop();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "Register Destroyed");
        super.onDestroy();
    }
}
