package com.jotreewater.socialsound;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.spotify.protocol.types.Image;
import com.spotify.protocol.types.ImageUri;
import com.spotify.protocol.types.Uri;

import java.util.ArrayList;

public class SonglistFragment extends Fragment {
    private RecyclerView songListRV;

    // Arraylist for storing data
    private ArrayList<SongnodeFragment> courseModelArrayList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstaceState){
        View view = inflater.inflate(R.layout.fragment_sounds, parent, false);
        songListRV = view.findViewById(R.id.songList);


        // here we have created new array list and added data to it.
        courseModelArrayList = new ArrayList<>();
        courseModelArrayList.add(new SongnodeFragment("SUGAR", "BROCKHAMPTON - GINGER", "Shared by Ernesto B.", "spotify:track:6U0FIYXCQ3TGrk4tFpLrEA", new ImageUri("spotify:image:ab67616d0000b27346f07fa4f28bf824840ddacb")));
        courseModelArrayList.add(new SongnodeFragment("Come As You Are", "Nirvana - Nevermind", "Shared by Ernesto B.", "spotify:track:6U0FIYXCQ3TGrk4tFpLrEA", new ImageUri("spotify:image:ab67616d0000b273e175a19e530c898d167d39bf")));
        courseModelArrayList.add(new SongnodeFragment("Miami", "Will Smith - Big Willie Smith", "Shared by Ernesto B.", "spotify:track:6U0FIYXCQ3TGrk4tFpLrEA", new ImageUri("spotify:image:ab67616d0000b273ddf2f9edabd166c60047e3c4")));
        courseModelArrayList.add(new SongnodeFragment("Into the Unknown - Panic! At The Disco Version", "JPEGMAFIA - Veteran", "Shared by Ernesto B.", "spotify:track:6U0FIYXCQ3TGrk4tFpLrEA", new ImageUri("spotify:image:ab67616d0000b2736ff59d18c018a2845758deed")));
        courseModelArrayList.add(new SongnodeFragment("D.A.N.C.E.", "Justice - Justice", "Shared by Ernesto B.", "spotify:track:6U0FIYXCQ3TGrk4tFpLrEA", new ImageUri("spotify:image:ab67616d0000b27346f07fa4f28bf824840ddacb")));
        courseModelArrayList.add(new SongnodeFragment("CALLIGRAPHY", "Saba - CARE FOR ME", "Shared by Ernesto B.", "spotify:track:6U0FIYXCQ3TGrk4tFpLrEA", new ImageUri("spotify:image:ab67616d0000b27346f07fa4f28bf824840ddacb")));
        courseModelArrayList.add(new SongnodeFragment("Chamber of Reflection", "Mac DeMarco - Salad Days", "Shared by Ernesto B.", "spotify:track:6U0FIYXCQ3TGrk4tFpLrEA", new ImageUri("spotify:image:ab67616d0000b27346f07fa4f28bf824840ddacb")));

        // we are initializing our adapter class and passing our arraylist to it.
        SongnodeAdapter SongnodeAdapter = new SongnodeAdapter(this.getContext(), courseModelArrayList);

        // below line is for setting a layout manager for our recycler view.
        // here we are creating vertical list so we will provide orientation as vertical
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getContext(), LinearLayoutManager.VERTICAL, false);

        // in below two lines we are setting layout manager and adapter to our recycler view.
        songListRV.setLayoutManager(linearLayoutManager);
        songListRV.setAdapter(SongnodeAdapter);

        SongnodeAdapter.setOnItemClickListener(new SongnodeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                System.out.println(position);
                playUri((courseModelArrayList.get(position)).getSong_uri().toString());
            }
        });

        return view;
    }

    // Function to play a specific track given by the parameter URI
    private void playUri(String uri) {
        MainActivity.mainSpotifyAppRemote
                .getPlayerApi()
                .play(uri);
    }
}
